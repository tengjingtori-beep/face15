#import "RootViewController.h"

// Face15App (stage 0, placeholder):
// This app will own face registration in stage 2 (enrolment runs
// while the phone is unlocked; unlocking itself never depends on
// this app, because apps cannot be opened while the phone is
// locked — the lock-screen component lives in the tweak).
// Stage 0 shows only the title, a note and the version.
@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (@available(iOS 13.0, *)) {
        self.view.backgroundColor = [UIColor systemBackgroundColor];
    } else {
        self.view.backgroundColor = [UIColor whiteColor];
    }

    UILabel *title = [[UILabel alloc] init];
    title.text = @"Face15";
    title.font = [UIFont boldSystemFontOfSize:34];
    title.textAlignment = NSTextAlignmentCenter;

    UILabel *note = [[UILabel alloc] init];
    note.text = @"顔の登録は段階2で実装します。\n今は枠だけです。";
    note.font = [UIFont systemFontOfSize:16];
    note.textAlignment = NSTextAlignmentCenter;
    note.numberOfLines = 0;

    UILabel *version = [[UILabel alloc] init];
    version.text = @"Face15 0.1.0（段階0：骨組み）";
    version.font = [UIFont systemFontOfSize:13];
    version.textColor = [UIColor grayColor];
    version.textAlignment = NSTextAlignmentCenter;

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[title, note, version]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 16;
    stack.alignment = UIStackViewAlignmentCenter;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [stack.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
        [stack.leadingAnchor constraintGreaterThanOrEqualToAnchor:self.view.leadingAnchor constant:24],
        [stack.trailingAnchor constraintLessThanOrEqualToAnchor:self.view.trailingAnchor constant:-24],
    ]];
}

@end
