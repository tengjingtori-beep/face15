// Face15 — entry point (stage 0, skeleton)
// iPhone 7 / iOS 15 / Dopamine (rootless).
// The filter plist injects this dylib into SpringBoard ONLY — on
// purpose: the lock screen is SpringBoard's own work, so the small
// recognition component that must run WHILE THE PHONE IS LOCKED has
// to live here (a normal app cannot be opened while locked, which
// is exactly the flaw v0.2 of the design fixed).
// Stage 0 does only this:
//   - start the manager when SpringBoard finishes launching
//     (log + prefs + failure brake),
//   - add ONE small "face unlock" button at the bottom of the lock
//     screen. Tapping it only logs and changes its label for a
//     moment. No camera, no unlocking yet (camera is stage 1).
// The lock-screen hook group is initialised ONLY when the class
// and the method really exist on this iOS, and every step is
// wrapped in @try/@catch, so a missing piece can never turn into a
// broken %orig call or a Safe Mode loop. The passcode UI is never
// touched or covered.

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "Face15Manager.h"

@interface SpringBoard : UIApplication
@end

@interface SBLockScreenViewController : UIViewController
@end

static void f15PrefsChanged(CFNotificationCenterRef center, void *observer,
                            CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[Face15Manager shared] reloadPrefs];
    });
}

%group Face15SpringBoardGroup
%hook SpringBoard
- (void)applicationDidFinishLaunching:(UIApplication *)application {
    %orig;
    F15Log(@"SPRINGBOARD_LAUNCHED");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        [[Face15Manager shared] setup];
    });
}
%end
%end

%group Face15LockGroup
%hook SBLockScreenViewController
- (void)viewDidAppear:(BOOL)animated {
    %orig;
    @try {
        F15Log(@"LOCKSCREEN_APPEARED");
        UIView *v = [(UIViewController *)self view];
        [[Face15Manager shared] lockScreenDidAppearWithView:v];
    } @catch (id e) {
        F15NoteException(@"SBLockScreenViewController.viewDidAppear", e);
    }
}
%end
%end

%ctor {
    @autoreleasepool {
        F15LoadPrefs();
        NSString *bid = [[NSBundle mainBundle] bundleIdentifier] ?: @"?";
        if ([bid isEqualToString:@"com.apple.springboard"]) {
            CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(), NULL,
                f15PrefsChanged, (__bridge CFStringRef)@"com.tori.face15.changed", NULL,
                CFNotificationSuspensionBehaviorDeliverImmediately);
            F15Log(@"DYLIB_LOADED version=0.1.0 process=%@", bid);
            %init(Face15SpringBoardGroup);
            // Install the lock-screen hook only when both the class
            // and the method really exist on this iOS.
            Class lockCls = NSClassFromString(@"SBLockScreenViewController");
            if (lockCls && [lockCls instancesRespondToSelector:@selector(viewDidAppear:)]) {
                %init(Face15LockGroup);
                F15Log(@"LOCK_HOOK_INSTALLED class=SBLockScreenViewController method=viewDidAppear:");
            } else {
                F15Log(@"LOCK_HOOK_SKIPPED classFound=%d (lock button will not appear; passcode/Touch ID unaffected)",
                       lockCls != nil);
            }
        }
    }
}
