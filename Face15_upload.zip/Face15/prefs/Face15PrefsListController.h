#import <Preferences/PSListController.h>

@interface Face15PrefsListController : PSListController
@end
