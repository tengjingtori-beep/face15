// Face15 — core (stage 0, skeleton)
//
// Stage 0 proves only the foundation on the real device:
//   - the dylib loads into SpringBoard only (narrow filter on
//     purpose: the lock screen is SpringBoard's own work, so the
//     recognition component that must run WHILE LOCKED lives here),
//   - the log file is written,
//   - prefs are read and re-read when Settings changes them,
//   - the failure brake exists (5 exceptions -> all activity stops
//     until respring),
//   - a small "face unlock" button appears at the bottom of the
//     lock screen. Tapping it only logs LOCK_BUTTON_TAPPED and
//     changes its label for a moment. NO camera, NO unlocking yet —
//     the camera experiment is stage 1, registration is stage 2.
// The button is small and sits in the bottom strip so it never
// covers the passcode UI, and it is added at most once per lock
// screen view.

#import "Face15Manager.h"

NSString * const kF15PrefsID = @"com.tori.face15";
NSString * const kF15PrefsChanged = @"com.tori.face15.changed";
static NSString * const kF15Version = @"0.1.0";
static const NSInteger kF15LockButtonTag = 150150;

// ---------- prefs ----------
static BOOL prefEnabled = YES;
static BOOL prefLockButton = YES;

static id F15AppValue(NSString *key) {
    return (__bridge_transfer id)CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                           (__bridge CFStringRef)kF15PrefsID);
}

void F15LoadPrefs(void) {
    @try {
        id v;
        v = F15AppValue(@"Enabled");           if (v) prefEnabled = [v boolValue];
        v = F15AppValue(@"LockButtonEnabled"); if (v) prefLockButton = [v boolValue];
        CFPreferencesAppSynchronize((__bridge CFStringRef)kF15PrefsID);
    } @catch (__unused id e) {}
}

BOOL F15Enabled(void) { return prefEnabled; }
BOOL F15LockButtonEnabled(void) { return prefLockButton; }

// ---------- log ----------
static NSFileHandle *f15LogHandle = nil;
static dispatch_queue_t f15LogQueue = nil;

static NSString *F15LogPath(void) {
    NSString *p = @"/var/mobile/Library/Logs/Face15.log";
    if ([NSFileManager.defaultManager fileExistsAtPath:p]) return p;
    NSString *dir = @"/var/mobile/Library/Logs";
    if ([NSFileManager.defaultManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil] &&
        [NSFileManager.defaultManager createFileAtPath:p contents:nil attributes:nil]) return p;
    return @"/var/tmp/Face15.log";
}

void F15Log(NSString *format, ...) {
    @try {
        va_list ap; va_start(ap, format);
        NSString *msg = [[NSString alloc] initWithFormat:format arguments:ap];
        va_end(ap);
        if (!f15LogQueue) f15LogQueue = dispatch_queue_create("com.tori.face15.log", DISPATCH_QUEUE_SERIAL);
        dispatch_async(f15LogQueue, ^{
            @try {
                if (!f15LogHandle) {
                    NSString *path = F15LogPath();
                    [NSFileManager.defaultManager createFileAtPath:path contents:nil attributes:nil];
                    f15LogHandle = [NSFileHandle fileHandleForWritingAtPath:path];
                }
                [f15LogHandle seekToEndOfFile];
                NSString *line = [NSString stringWithFormat:@"[%@] %@\n",
                    [NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterMediumStyle], msg];
                [f15LogHandle writeData:[line dataUsingEncoding:NSUTF8StringEncoding]];
                [f15LogHandle synchronizeFile];
            } @catch (__unused id e) {}
        });
    } @catch (__unused id e) {}
}

// ---------- failure brake ----------
// After kF15BrakeThreshold exceptions anywhere in the manager, the
// brake engages: all feature activity must check +[Face15Manager
// brakeOn] (and the master Enabled switch) before doing anything.
// The brake never auto-releases; a respring restarts the count. The
// standard iOS lock (passcode / Touch ID) is native SpringBoard and
// is never touched by this brake — it stays available regardless.
static NSInteger gExceptionCount = 0;
static BOOL gBrakeOn = NO;
static const NSInteger kF15BrakeThreshold = 5;

void F15NoteException(NSString *where, id error) {
    gExceptionCount++;
    F15Log(@"EXCEPTION %@: %@ (count=%ld)", where, error, (long)gExceptionCount);
    if (!gBrakeOn && gExceptionCount >= kF15BrakeThreshold) {
        gBrakeOn = YES;
        F15Log(@"BRAKE_ON exceptions reached %ld: all feature activity is stopped until respring", (long)gExceptionCount);
    }
}

// ---------- manager ----------
@interface Face15Manager ()
@property (nonatomic) BOOL setupDone;
@property (nonatomic, weak) UIButton *lockButton;
@end

@implementation Face15Manager

+ (instancetype)shared {
    static Face15Manager *s; static dispatch_once_t once;
    dispatch_once(&once, ^{ s = [[Face15Manager alloc] init]; });
    return s;
}

+ (BOOL)brakeOn { return gBrakeOn; }

- (void)reloadPrefs {
    F15LoadPrefs();
    F15Log(@"PREFS enabled=%d lockButton=%d brake=%d", prefEnabled, prefLockButton, gBrakeOn);
    // If the switches were turned off, take the button away too.
    if ((!prefEnabled || !prefLockButton) && self.lockButton) {
        [self.lockButton removeFromSuperview];
        self.lockButton = nil;
        F15Log(@"LOCK_BUTTON_REMOVED prefs off");
    }
}

- (void)setup {
    if (self.setupDone) return;
    self.setupDone = YES;
    @try {
        F15Log(@"SETUP_START version=%@", kF15Version);
        [self reloadPrefs];
        F15Log(@"STAGE0 skeleton only: lock-screen button frame + log + brake. No camera, no unlocking yet.");
        F15Log(@"SETUP_DONE");
    } @catch (id e) {
        F15NoteException(@"setup", e);
    }
}

// ---------- lock-screen button (stage 0 frame) ----------
- (void)lockScreenDidAppearWithView:(UIView *)view {
    @try {
        if (!view) return;
        if (!prefEnabled || !prefLockButton) {
            F15Log(@"LOCK_BUTTON_SKIPPED prefs enabled=%d lockButton=%d", prefEnabled, prefLockButton);
            return;
        }
        if (gBrakeOn) {
            F15Log(@"LOCK_BUTTON_SKIPPED brake on");
            return;
        }
        if ([view viewWithTag:kF15LockButtonTag]) {
            // Already added to this lock screen view: never stack two.
            return;
        }
        CGFloat w = 200.0, h = 36.0;
        CGFloat x = (view.bounds.size.width - w) / 2.0;
        CGFloat y = view.bounds.size.height - 46.0 - h; // bottom strip, clear of the passcode UI
        if (y < 0) y = 0;
        UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
        b.tag = kF15LockButtonTag;
        b.frame = CGRectMake(x, y, w, h);
        b.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin;
        b.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.55];
        b.layer.cornerRadius = h / 2.0;
        b.clipsToBounds = YES;
        b.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
        [b setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [b setTitle:@"顔で開ける" forState:UIControlStateNormal];
        [b addTarget:self action:@selector(lockButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:b];
        self.lockButton = b;
        F15Log(@"LOCK_BUTTON_ADDED frame={{%.0f,%.0f},{%.0f,%.0f}}", x, y, w, h);
    } @catch (id e) {
        F15NoteException(@"lockScreenDidAppear", e);
    }
}

- (void)lockButtonTapped:(UIButton *)sender {
    @try {
        F15Log(@"LOCK_BUTTON_TAPPED stage0: no camera, no unlocking yet");
        if (gBrakeOn) return;
        [sender setTitle:@"段階0：まだ開けません" forState:UIControlStateNormal];
        __weak UIButton *weakBtn = sender;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            @try {
                if (weakBtn && weakBtn.superview) {
                    [weakBtn setTitle:@"顔で開ける" forState:UIControlStateNormal];
                }
            } @catch (__unused id e) {}
        });
    } @catch (id e) {
        F15NoteException(@"lockButtonTapped", e);
    }
}

@end
