#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// Face15 manager (stage 0, skeleton):
// owns the diagnostic log, the prefs snapshot, the failure brake
// and the small lock-screen button frame.
// Later stages plug in here:
//   stage 1: lock-screen camera experiment (can the lock-screen
//            component use the front camera while locked?)
//   stage 2: registration data (feature numbers only) + matching
//   stage 3: app lock connection (OK signal only)
// Every feature path must pass through the brake and write to the
// log so a failure can be traced from the log alone. The manager
// must never block the passcode UI: face is an additional entrance,
// never the only one.
@interface Face15Manager : NSObject
+ (instancetype)shared;
- (void)setup;
- (void)reloadPrefs;
+ (BOOL)brakeOn;
// Called from the SBLockScreenViewController hook (main queue).
- (void)lockScreenDidAppearWithView:(UIView *)view;
@end

// Shared prefs / logging / brake helpers used by Tweak.x too.
void F15LoadPrefs(void);
void F15Log(NSString *format, ...);
void F15NoteException(NSString *where, id error);
BOOL F15Enabled(void);
BOOL F15LockButtonEnabled(void);
